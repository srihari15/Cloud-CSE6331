'''
NAME : Srihari Chandramouli
ID : 1001529776


References:
https://pythonprogramming.net/k-means-titanic-dataset-machine-learning-tutorial/
https://stackoverflow.com/questions/40828929/sklearn-mean-distance-from-centroid-of-each-cluster

'''



from sklearn import cluster
import pandas as pd
import numpy as np
import os
from flask import Flask, render_template, request
import sqlite3
import timeit
import matplotlib.pyplot as plt
import random


app = Flask(__name__)
port = int(os.getenv('PORT', 8000))
data = pd.read_csv('titanic3.csv')
#data.drop(['body','name'], 1, inplace=True)
#data.convert_objects(convert_numeric=True)
data.fillna(0, inplace=True)


@app.route('/c', methods=['GET','POST'])
def c():
    if request.method == "POST":
        file = request.files['myfile']
        #print(file)
    start_time = timeit.default_timer()
    data = pd.read_csv(file)
    con = sqlite3.connect('titanic.db')
    con.row_factory = sqlite3.Row
    data.to_sql(name="titanic", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute('SELECT * from titanic ')
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('list.html', full=full, finish_time=finish_time)


def handle_non_numerical_data(df):
    columns = df.columns.values

    for column in columns:
        text_digit_vals = {}

        def convert_to_int(val):
            return text_digit_vals[val]

        if df[column].dtype != np.int64 and df[column].dtype != np.float64:
            column_contents = df[column].values.tolist()
            unique_elements = set(column_contents)
            x = 0
            for unique in unique_elements:
                if unique not in text_digit_vals:
                    text_digit_vals[unique] = x
                    x += 1

            df[column] = list(map(convert_to_int, df[column]))

    return df


data = handle_non_numerical_data(data)


@app.route('/')
def home():
    return render_template('homekmeans4.html')


@app.route('/query15')
def query15():

    data1 = data['fare']
    data2 = data['age']
    X = list(zip(data1, data2))
    #print(X)

    k = 5
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query15.html', num_of_points=num_of_points, centroids=centroi, dist = dist_from_clus, count= count)


@app.route('/query25')
def query25():

    data1 = data['survived']
    data2 = data['fare']
    X = list(zip(data1, data2))
    #print(X)

    k = 5
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query25.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count= count)


@app.route('/query35')
def query35():

    data1 = data['cabin']
    data2 = data['fare']
    X = list(zip(data1, data2))
    #print(X)

    k = 5
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query35.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count=count)


@app.route('/query110')
def query110():
    data1 = data['fare']
    data2 = data['age']
    X = list(zip(data1, data2))
    #print(X)

    k = 20
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query120.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count= count)


@app.route('/query210')
def query210():
    data1 = data['survived']
    data2 = data['fare']
    X = list(zip(data1, data2))
    #print(X)

    k = 20
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query220.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count=count)


@app.route('/query310')
def query310():
    data1 = data['cabin']
    data2 = data['fare']
    X = list(zip(data1, data2))
    # print(X)

    k = 20
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query320.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count=count)


@app.route('/query1100')
def query1100():
    data1 = data['fare']
    data2 = data['age']
    X = list(zip(data1, data2))
    # print(X)

    k = 100
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query1100.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count=count)


@app.route('/query2100')
def query2100():
    data1 = data['survived']
    data2 = data['fare']
    X = list(zip(data1, data2))
    # print(X)

    k = 100
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query2100.html', num_of_points=num_of_points, centroids=cent_len, dist = dist_from_clus, count= count)


@app.route('/query3100')
def query3100():
    data1 = data['cabin']
    data2 = data['fare']
    X = list(zip(data1, data2))
    # print(X)

    k = 100
    kmeans = cluster.KMeans(n_clusters=k)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    num_of_points = len(labels)
    cent_len = len(centroids)
    #dist = np.mean(centroids)
    dist = np.linalg.norm(centroids)
    unique, counts = np.unique(labels, return_counts=True)
    count = dict(zip(unique, counts))
    dist_from_clus = []

    for i in range(0, k):
        for j in range(i + 1, k):
            dist = np.linalg.norm(centroids[i] - centroids[j])
            dist_from_clus.append(dist)
    return render_template('query3100.html', num_of_points=num_of_points, centroids=cent_len, dist=dist_from_clus, count=count)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
#\myplot.png
