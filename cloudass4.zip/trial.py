from sklearn import cluster
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import distance
import os
from flask import Flask, render_template, request
import sqlite3
import timeit
import random



data = pd.read_csv('titanic3.csv')
data.fillna(0, inplace=True)
data1 = data['fare']
data2 = data['age']
X = list(zip(data1, data2))
XX = np.array(X)
#print(X)
#print(XX)
k = 5
kmeans = cluster.KMeans(n_clusters=k)
kmeans.fit(X)

labels = kmeans.labels_
centroids = kmeans.cluster_centers_
num_of_points = len(labels)
cent_len = len(centroids)
# dist = np.mean(centroids)

dist_from_clus = []

for i in range(0, k):
    for j in range(i+1, k):
        dist = np.linalg.norm(centroids[i] - centroids[j])
        dist_from_clus.append(dist)
print(dist_from_clus)
unique, counts = np.unique(labels, return_counts=True)
count = dict(zip(unique, counts))
#print(count)


plt.scatter(XX[:,0], XX[:,1], c=labels, cmap='rainbow')
plt.scatter(centroids[:,0] ,centroids[:,1], color='black')
plt.show()
