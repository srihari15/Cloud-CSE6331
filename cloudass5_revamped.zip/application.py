import pandas as pd
import sqlite3
from flask import Flask, render_template, request
import numpy as np
from sklearn import cluster


application = Flask(__name__)


def handle_non_numerical_data(df):
    columns = df.columns.values

    for column in columns:
        text_digit_vals = {}

        def convert_to_int(val):
            return text_digit_vals[val]

        if df[column].dtype != np.int64 and df[column].dtype != np.float64:
            column_contents = df[column].values.tolist()
            unique_elements = set(column_contents)
            x = 0
            for unique in unique_elements:
                if unique not in text_digit_vals:
                    text_digit_vals[unique] = x
                    x += 1

            df[column] = list(map(convert_to_int, df[column]))

    return df



@application.route('/')
def home():
    return render_template('home.html')


@application.route('/c', methods=['GET', 'POST'])
def c():
    if request.method == "POST":
        file = request.files['myfile']
        # print(file)

    data = pd.read_csv(file)
    #data = handle_non_numerical_data(data)
    #data.fillna(0, inplace=True)
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)

    cur = con.cursor()
    cur.execute("SELECT * from earthquake ")
    full = cur.fetchall()
    return render_template('listearthquake.html', full=full)


@application.route('/input1')
def input1():
    return render_template('input1.html')


@application.route('/query1', methods=['GET', 'POST'])
def query1():
    # if request.method == "POST":
    #   file = request.files['myfile']

    # data = pd.read_csv('all_month.csv')
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    # data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)

    cur = con.cursor()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 2.0 AND 2.5)")
    full1 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 2.5 AND 3.0)")
    full2 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 3.0 AND 3.5)")
    full3 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 3.5 AND 4.0)")
    full4 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 4.0 AND 4.5)")
    full5 = cur.fetchone()
    rows = [full1[0], full2[0], full3[0], full4[0], full5[0]]
    return render_template('piechart.html', rows=rows)


@application.route('/query2', methods=['GET', 'POST'])
def query2():
    # if request.method == "POST":
    #   file = request.files['myfile']

    # data = pd.read_csv('all_month.csv')
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    # data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)

    cur = con.cursor()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 2.0 AND 2.5)")
    full1 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 2.5 AND 3.0)")
    full2 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 3.0 AND 3.5)")
    full3 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 3.5 AND 4.0)")
    full4 = cur.fetchone()
    cur.execute("SELECT count(mag) from earthquake where (mag BETWEEN 4.0 AND 4.5)")
    full5 = cur.fetchone()
    rows = [full1[0], full2[0], full3[0], full4[0], full5[0]]
    return render_template('barchart.html', rows=rows)


@application.route('/titanic', methods=['GET', 'POST'])
def titanic():
    if request.method == "POST":
        file = request.files['myfile1']
        # print(file)

    data = pd.read_csv(file)
    #data = handle_non_numerical_data(data)
    #data.fillna(0, inplace=True)
    con = sqlite3.connect('titanic.db')
    con.row_factory = sqlite3.Row
    data.to_sql(name="titanic", con=con, if_exists="replace", index=False)

    cur = con.cursor()
    cur.execute("SELECT * from titanic ")
    full = cur.fetchall()
    return render_template('listtitanic.html', full=full)


@application.route('/input2')
def input2():
    return render_template('input2.html')


@application.route('/query3', methods=['GET', 'POST'])
def query3():
    # if request.method == "POST":
    #   file = request.files['myfile']

    # data = pd.read_csv('all_month.csv')
    sex = request.form['sex']
    con = sqlite3.connect('titanic.db')
    con.row_factory = sqlite3.Row
    # data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute("SELECT count(survived) from titanic where sex = ? and survived=1 ", (sex,))
    full = cur.fetchone()
    cur.execute("SELECT count(survived) from titanic where sex = ? and survived=0 ", (sex,))
    full1 = cur.fetchone()
    return render_template('piecharttitanic.html', full=full, full1=full1)


@application.route('/query4', methods=['GET', 'POST'])
def query4():
    # if request.method == "POST":
    #   file = request.files['myfile']

    # data = pd.read_csv('all_month.csv')
    #sex = request.form['sex']
    con = sqlite3.connect('titanic.db')
    con.row_factory = sqlite3.Row
    # data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute("SELECT count(survived) from titanic where sex = 'male' and survived=1 ")
    full = cur.fetchone()
    print(full)

    return render_template('barcharttitanic.html', full=full)


@application.route('/query5', methods=['GET', 'POST'])
def query5():
    # if request.method == "POST":
    #   file = request.files['myfile']

    data = pd.read_csv('titanic3.csv')
    data = handle_non_numerical_data(data)
    data.fillna(0, inplace=True)
    con = sqlite3.connect('titanic.db')
    con.row_factory = sqlite3.Row
    # data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute("SELECT * from titanic ")
    full = cur.fetchall()
    data1 = data['fare']
    data2 = data['age']
    X = list(zip(data1, data2))
    #k = int(request.form['k'])
    kmeans = cluster.KMeans(n_clusters=8)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    return render_template('scattertitanic.html', centroids=centroids)


if __name__ == '__main__':
    application.run(debug=True)

