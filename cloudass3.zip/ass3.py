import pandas as pd
import sqlite3
from flask import Flask, render_template, request
#from sklearn.cluster import KMeans
import timeit
import os
from random import randint
from pymemcache.client.hash import HashClient
#import bmemcached

app = Flask(__name__)
port = int(os.getenv('PORT', 8000))

#print(os.path.getsize('all_month.csv'))

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/c', methods=['GET','POST'])
def c():
    if request.method == "POST":
        file = request.files['myfile']
        #print(file)
    start_time = timeit.default_timer()
    data = pd.read_csv(file)
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()

    cur.execute('SELECT * from earthquake WHERE rms > 0.25')
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('list.html', full=full, finish_time=finish_time)


@app.route('/numquery', methods=['GET','POST'])
def numquery():
    return render_template('numqueries.html')


@app.route('/query1', methods=['GET','POST'])
def query1():
    num = request.form['num']
    number = int(request.form['number'])
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    start_time = timeit.default_timer()
    for i in range(1, number):
        r = randint(5, 10)
       # cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (r,))
        cur.execute("SELECT  net, id FROM earthquake WHERE net like ?",(num+'%',))
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('query1.html', full=full, finish_time=finish_time)


@app.route('/numquerycached', methods=['GET','POST'])
def numquerycached():
    return render_template('numqueriescached.html')


@app.route('/query1cached', methods=['GET','POST'])
def query1cached():
    #client = Client('memcached-16912.c15.us-east-1-2.ec2.cloud.redislabs.com:16912', 'mc-Y8Oiq', 'jcuByu4KcZNMX2wHXImlD0ue94aNwFCz ' )
    client = HashClient([('127.0.0.1', 11211)])

    num = int(request.form['num'])
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    start_time = timeit.default_timer()
    for i in range(1, num):
        r = randint(5, 10)
        #cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (r,))
        cur.execute('select * from earthquake limit ?', (r,))
    full = cur.fetchall()
    client.set('key1', full)
    result = client.get('key1')
    finish_time = timeit.default_timer() - start_time
    return render_template('query1cached.html',result=result, finish_time=finish_time)


@app.route('/numquery2', methods=['GET','POST'])
def numquery2():
    return render_template('numqueries2.html')


@app.route('/query2', methods=['GET','POST'])
def query2():
    num = int(request.form['num'])
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    start_time = timeit.default_timer()
    for i in range(1, num):
        r = randint(1, 6)
        cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (r,))
        #cur.execute('select * from earthquake limit ?', (r,))
    full = cur.fetchone()
    finish_time = timeit.default_timer() - start_time
    return render_template('query2.html', full=full, finish_time=finish_time)


@app.route('/numquery2cached', methods=['GET','POST'])
def numquery2cached():
    return render_template('numqueries2cached.html')


@app.route('/query2cached', methods=['GET','POST'])
def query2cached():
    #client = bmemcached.Client('memcached-16912.c15.us-east-1-2.ec2.cloud.redislabs.com:16912', 'mc-Y8Oiq', 'jcuByu4KcZNMX2wHXImlD0ue94aNwFCz ')
    client = HashClient([('127.0.0.1', 11211)])

    num = int(request.form['num'])
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    start_time = timeit.default_timer()
    for i in range(1, num):
        r = randint(1, 6)
        cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (r,))
        #cur.execute('select * from earthquake limit ?', (r,))
    full = cur.fetchone()
    client.set('key', full)
    result = client.get('key')
    finish_time = timeit.default_timer() - start_time
    return render_template('query2cached.html',result=result, finish_time=finish_time)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)

#C:\Users\sriha\Downloads\memcached-win64-1.4.4-14