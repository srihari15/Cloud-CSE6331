import pandas as pd
import sqlite3
from flask import Flask, render_template, request
import timeit


application = Flask(__name__)


#print(os.path.getsize('all_month.csv'))


@application.route('/')
def home():
    return render_template('home.html')


@application.route('/c', methods=['GET','POST'])
def c():
    if request.method == "POST":
        file = request.files['myfile']
        #print(file)
    data = pd.read_csv(file)
    start_time = timeit.default_timer()
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)

    cur = con.cursor()
    cur.execute('SELECT * from earthquake')
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('list.html', full=full, finish_time=finish_time)


@application.route('/input1')
def input1():
    return render_template('input1.html')


@application.route('/query1', methods=['GET','POST'])
def query1():
    #if request.method == "POST":
     #   file = request.files['myfile']

    #data = pd.read_csv('all_month.csv')
    start_time = timeit.default_timer()
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    mag = request.form['mag']
    #data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    end = []
    fulllist = []
    for i in range(0, 100):
        start = timeit.default_timer()
        cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (mag,))
        full = cur.fetchone()
        fulllist.append(full)
        end = timeit.default_timer() - start
    finish_time = timeit.default_timer() - start_time
    return render_template('query1.html',full=fulllist, finish_time=finish_time, end=end)



@application.route('/input2')
def input2():
    return render_template('input2.html')


@application.route('/query2', methods=['GET','POST'])
def query2():
    #if request.method == "POST":
     #   file = request.files['myfile']

    #data = pd.read_csv('all_month.csv')
    range1 = request.form['range1']
    range2 = request.form['range2']
    start_time = timeit.default_timer()
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    #data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    #cur.execute("SELECT * from earthquake where (mag BETWEEN ? AND ?) AND (time BETWEEN '2018-06-01T01:42:58.020Z' AND '2018-06-07T01:42:58.020Z') ",(range1, range2,))
    cur.execute("SELECT * from earthquake where (mag BETWEEN ? AND ?) ",(range1, range2,))
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('query2.html', full=full, finish_time=finish_time)


@application.route('/input3')
def input3():
    return render_template('input3.html')


@application.route('/query3', methods=['GET','POST'])
def query3():
    #if request.method == "POST":
     #   file = request.files['myfile']

    #data = pd.read_csv('all_month.csv')
    location = request.form['location']
    range1 = int(request.form['range1'])
    range2 = int(request.form['range2'])
    start_time = timeit.default_timer()
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    #data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute("SELECT *, CAST(place AS INTEGER ) as p from earthquake where locationSource = ? and p BETWEEN ? AND ? ",(location, range1, range2,))
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('query3.html', full=full, finish_time=finish_time)



@application.route('/input7', methods=['GET','POST'])
def input7():
    return render_template('input7.html')


@application.route('/query7', methods=['GET','POST'])
def query7():
    num = request.form['num']
    number = int(request.form['number'])
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    start_time = timeit.default_timer()
    for i in range(1, number):
        #r = randint(5, 10)
       # cur.execute('SELECT COUNT(mag) from earthquake where mag > ?', (r,))
        cur.execute("SELECT  time, locationSource FROM earthquake WHERE net like ?",(num+'%',))
    full = cur.fetchall()
    finish_time = timeit.default_timer() - start_time
    return render_template('query7.html', full=full, finish_time=finish_time)




'''
@application.route('/query4', methods=['GET','POST'])
def query4():

    variables = pd.read_csv('all_month.csv')
    Y = variables[['latitude']]
    X = variables[['longitude']]

    Nc = range(1, 10)
    kmeans = [KMeans(n_clusters=i) for i in Nc]

    # kmeans
    score = [kmeans[i].fit(Y).score(Y) for i in range(len(kmeans))]
    #print(score)
    return render_template('query4.html', score=score)


@application.route('/query5', methods=['GET','POST'])
def query5():
    #if request.method == "POST":
     #   file = request.files['myfile']

    #data = pd.read_csv('all_month.csv')
    con = sqlite3.connect('earthquake.db')
    con.row_factory = sqlite3.Row
    #data.to_sql(name="earthquake", con=con, if_exists="replace", index=False)
    cur = con.cursor()
    cur.execute("SELECT cast(strftime('%H', TIME(time)) as INTEGER) as H, mag from earthquake where H between 0 and 6 or H BETWEEN 20 and 23 and mag < 4.0 ")
    full = cur.fetchall()
    return render_template('query5.html', full=full)
'''


if __name__ == '__main__':
    application.run(debug=True)

