import urllib.request
from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/query1', methods=['GET','POST'])
def query1():

    val = int(request.form['val'])
    for i in range(0, val):
        urllib.request.urlopen("http://cloudass7-env.ufmtm2xygq.us-east-2.elasticbeanstalk.com/")
        #print('hi')

    return render_template('query1.html')


if __name__ == '__main__':
    app.run(debug=True)


